export enum toastTypes {
    success = "success",
    error = "error",
    info = "info",
    warning = "warning"
}
