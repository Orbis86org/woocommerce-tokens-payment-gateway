export type HSuiteNodeConfig = {
    operator: string,
    publicKey: string,
    url: string;
}