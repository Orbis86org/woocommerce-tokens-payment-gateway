export type StatsSwapsWalletDto = {
    count: number;
    label: string,
}