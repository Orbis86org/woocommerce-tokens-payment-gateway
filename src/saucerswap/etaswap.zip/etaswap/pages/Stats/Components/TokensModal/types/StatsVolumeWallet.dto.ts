export type StatsVolumeWalletDto = {
    amountHBAR: string,
    amountUSD: string,
    label: string,
}