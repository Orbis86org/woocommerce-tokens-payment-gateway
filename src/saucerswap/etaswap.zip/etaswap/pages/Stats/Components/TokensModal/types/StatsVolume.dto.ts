export type StatsVolumeDto = {
    volumeHBAR: string;
    volumeUSD: string;
    label: string;
}