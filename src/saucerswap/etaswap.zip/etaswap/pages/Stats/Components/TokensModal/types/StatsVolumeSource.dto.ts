export type StatsVolumeSourceDto = {
    EtaSwapHBAR: string,
    EtaSwapUSD: string,
    KabilaHBAR: string,
    KabilaUSD: string,
    "Unknown / Not specifiedHBAR": string,
    "Unknown / Not specifiedUSD": string,
    label: string,
}