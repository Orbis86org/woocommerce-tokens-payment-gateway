export type StackColumn = {
    label: string;
    type: string;
    value: number;
}