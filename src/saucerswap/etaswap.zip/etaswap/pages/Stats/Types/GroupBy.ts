export enum STATS_GROUP_BY {
    DAY = 'DAY',
    WEEK = 'WEEK',
    MONTH = 'MONTH',
}