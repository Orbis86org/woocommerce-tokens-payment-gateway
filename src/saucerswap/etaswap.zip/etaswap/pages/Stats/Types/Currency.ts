export enum STATS_CURRENCY {
    USD = 'USD',
    HBAR = 'HBAR',
}