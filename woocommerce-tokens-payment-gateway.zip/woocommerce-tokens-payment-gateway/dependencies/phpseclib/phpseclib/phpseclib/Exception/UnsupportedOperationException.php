<?php

/**
 * UnsupportedOperationException
 *
 * PHP version 5
 *
 * @author    Jim Wigginton <terrafrost@php.net>
 * @copyright 2015 Jim Wigginton
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://phpseclib.sourceforge.net
 */

namespace phpseclib3\Exception;

/**
 * UnsupportedOperationException
 *
 * @author  Jim Wigginton <terrafrost@php.net>
 */
class UnsupportedOperationException extends \RuntimeException
{
}
